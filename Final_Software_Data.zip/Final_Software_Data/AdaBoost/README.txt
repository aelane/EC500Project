*********************************
* README - ADABOOST SOURCE CODE *
*********************************

This folder contains the modified source code to run AdaBoost in this project. It also contains the license from the original writer. Finally, simple synthetic data and a .m file were used to test the modified functions.
The functions are duplicated in the Diabetes and Thyroid folders for ease of script use

MATLAB CODE FUNCTION
test_adaboost.m
train_adaboost.m
ApplyClassThreshold.m

ORIGINAL FILES FROM KROON
adaboost.m
example.m
license.txt

MATLAB TEST FILES
data_knnSimulation.mat
knn_data_example.m


————————————————————————————————————





